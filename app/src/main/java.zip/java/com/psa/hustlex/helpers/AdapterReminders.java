package com.psa.hustlex.helpers;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.psa.hustlex.R;
import com.psa.hustlex.models.Reminders;
import com.psa.hustlex.datastructures.CustomPriorityQueue;

import java.util.Iterator;

public class AdapterReminders extends RecyclerView.Adapter<AdapterReminders.MyViewHolder> {
    private final CustomPriorityQueue<Reminders> reminderQueue;
    private CustomPriorityQueue<Reminders> displayQueue; // Temporary cache for display
    private OnDeleteClickListener onDeleteClickListener;

    // Interface for the delete button click listener
    public interface OnDeleteClickListener {
        void onDeleteClick(int position);
    }

    // Constructor to set the reminder queue and the delete button click listener
    public AdapterReminders(CustomPriorityQueue<Reminders> reminderQueue, OnDeleteClickListener onDeleteClickListener) {
        this.reminderQueue = reminderQueue;
        this.displayQueue = new CustomPriorityQueue<>(reminderQueue.size());
        this.onDeleteClickListener = onDeleteClickListener;
        cacheReminders(); // Populate the display cache
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.reminder_item, parent, false);
        return new MyViewHolder(view, onDeleteClickListener);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        // Ensure cache is up to date
        if (reminderQueue.size() != displayQueue.size()) {
            cacheReminders();
        }

        // Access reminders directly by polling, which respects their priority order
        Reminders reminder = null;
        CustomPriorityQueue<Reminders> tempQueue = new CustomPriorityQueue<>(displayQueue.size());
        for (int i = 0; i <= position; i++) {
            if (!displayQueue.isEmpty()) {
                reminder = displayQueue.dequeue();
                tempQueue.enqueue(reminder);
            }
        }

        // Restore the displayQueue from tempQueue
        displayQueue = tempQueue;

        if (reminder != null) {
            holder.message.setText(reminder.getMessage());
            holder.time.setText(reminder.getRemindDate().toString());
        }
    }

    private void cacheReminders() {
        displayQueue.clear();
        Iterator<Reminders> iterator = reminderQueue.iterator();
        while (iterator.hasNext()) {
            displayQueue.enqueue(iterator.next());
        }
    }

    @Override
    public int getItemCount() {
        return reminderQueue.size();
    }

    static class MyViewHolder extends RecyclerView.ViewHolder {
        final TextView message;
        final TextView time;
        final Button buttonDelete;

        MyViewHolder(@NonNull View itemView, final OnDeleteClickListener onDeleteClickListener) {
            super(itemView);
            message = itemView.findViewById(R.id.textView1);
            time = itemView.findViewById(R.id.textView2);
            buttonDelete = itemView.findViewById(R.id.buttonDelete);

            // Set OnClickListener for the delete button
            buttonDelete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (onDeleteClickListener != null) {
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            onDeleteClickListener.onDeleteClick(position);
                        }
                    }
                }
            });
        }
    }
}
